package AssistedPractice8;

class Shape {
    // Fields
    private String color;

    // Constructor
    public Shape(String color) {
        this.color = color;
    }

    // Getter method for color
    public String getColor() {
        return color;
    }

    // Method to display information about the shape
    public void display() {
        System.out.println("Color: " + color);
    }
}

// Class representing a specific type of shape (Circle) extending the Shape class
class Circle extends Shape {
    // Fields
    private double radius;

    // Constructor
    public Circle(String color, double radius) {
        super(color);
        this.radius = radius;
    }

    // Method to calculate and return the area of the circle
    public double calculateArea() {
        return Math.PI * radius * radius;
    }

    // Overriding the display method to provide additional information
    @Override
    public void display() {
        super.display();
        System.out.println("Shape: Circle");
        System.out.println("Radius: " + radius);
        System.out.println("Area: " + calculateArea());
    }
}

public class OOPDemo {
    public static void main(String[] args) {
        // Creating an object of the Circle class
        Circle myCircle = new Circle("Red", 5.0);

        // Using methods and displaying information
        myCircle.display();

        // Demonstrating polymorphism
        Shape anotherShape = new Circle("Blue", 3.0);
        anotherShape.display();
    }
}