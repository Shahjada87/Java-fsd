package AssistedPractice9;

interface A {
    void display();
}

// Define two interfaces (B and C) that extend the common interface A
interface B extends A {
    void show();
}

interface C extends A {
    void print();
}

// Implement the derived interface D that extends both B and C
interface D extends B, C {
    void output();
}

// Implement the classes X and Y that provide concrete implementations
class X implements B {
    public void display() {
        System.out.println("Display method in class X");
    }

    public void show() {
        System.out.println("Show method in class X");
    }
}

class Y implements C {
    public void display() {
        System.out.println("Display method in class Y");
    }

    public void print() {
        System.out.println("Print method in class Y");
    }
}

// Implement the derived class Z that extends both X and Y
class Z implements D {
    public void display() {
        System.out.println("Display method in class Z");
    }

    public void show() {
        System.out.println("Show method in class Z");
    }

    public void print() {
        System.out.println("Print method in class Z");
    }

    public void output() {
        System.out.println("Output method in class Z");
    }
}

public class DiamondProblemExample {
    public static void main(String[] args) {
        Z obj = new Z();
        obj.display();
        obj.show();
        obj.print();
        obj.output();
    }
}