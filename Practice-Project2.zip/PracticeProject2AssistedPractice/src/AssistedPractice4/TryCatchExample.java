package AssistedPractice4;

import java.util.Scanner;

public class TryCatchExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter two numbers for division:");

        try {
            // Read two numbers from the user
            System.out.print("Enter numerator: ");
            int numerator = scanner.nextInt();

            System.out.print("Enter denominator: ");
            int denominator = scanner.nextInt();

            // Perform division and display the result
            int result = divideNumbers(numerator, denominator);
            System.out.println("Result of division: " + result);
        } catch (ArithmeticException e) {
            // Catch division by zero exception
            System.out.println("Error: Division by zero is not allowed.");
        } catch (Exception e) {
            // Catch other exceptions
            System.out.println("An error occurred: " + e.getMessage());
        } finally {
            // Close the scanner in the finally block to ensure it always gets closed
            scanner.close();
        }
    }

    // Method to perform division
    private static int divideNumbers(int numerator, int denominator) {
        return numerator / denominator;
    }
}