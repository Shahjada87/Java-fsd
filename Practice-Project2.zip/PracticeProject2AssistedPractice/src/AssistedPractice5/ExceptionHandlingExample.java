package AssistedPractice5;

import java.util.Scanner;

//Custom exception class
class CustomException extends Exception {
 public CustomException(String message) {
     super(message);
 }
}

public class ExceptionHandlingExample {
 public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);

     try {
         // Use of throws in method signature to declare possible exceptions
         inputAndDivide(scanner);
     } catch (ArithmeticException e) {
         System.out.println("Error: Division by zero is not allowed.");
     } catch (CustomException e) {
         System.out.println("Custom Exception: " + e.getMessage());
     } finally {
         // Code in finally block will always execute, whether an exception occurs or not
         System.out.println("Finally block executed.");
         scanner.close(); // Close the scanner to release resources
     }
 }

 // Method that may throw ArithmeticException or CustomException
 private static void inputAndDivide(Scanner scanner) throws ArithmeticException, CustomException {
     System.out.println("Enter two numbers for division:");

     int numerator = scanner.nextInt();
     int denominator = scanner.nextInt();

     try {
         if (denominator == 0) {
             // Use of throw to manually throw an exception
             throw new ArithmeticException("Division by zero");
         }

         int result = numerator / denominator;
         System.out.println("Result of division: " + result);

         // Use of throws in method signature to declare possible exceptions
         validateResult(result);
     } catch (ArithmeticException e) {
         // Catching the exception and rethrowing it as a custom exception
         throw new CustomException("Custom Exception: " + e.getMessage());
     }
 }

 // Method that throws a custom exception
 private static void validateResult(int result) throws CustomException {
     if (result < 0) {
         throw new CustomException("Result is negative");
     }
 }
}