package AssistedPractice6;

import java.util.Scanner;

public class ExceptionHandlingDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Getting input from the user
            System.out.print("Enter a number: ");
            int number = scanner.nextInt();

            // Performing a division
            int result = 10 / number;

            // Displaying the result
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            // Handling division by zero
            System.out.println("Error: Division by zero is not allowed.");
        } catch (Exception e) {
            // Handling other exceptions
            System.out.println("An error occurred: " + e.getMessage());
        } finally {
            // Closing the scanner in the finally block
            scanner.close();
        }
    }
}