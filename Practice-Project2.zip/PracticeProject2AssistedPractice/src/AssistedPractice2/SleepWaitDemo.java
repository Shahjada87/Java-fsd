package AssistedPractice2;

public class SleepWaitDemo {
	public static void main(String[] args) {
        final SharedResource sharedResource = new SharedResource();

        // Thread 1: Sleep example
        Thread sleepThread = new Thread(() -> {
            try {
                System.out.println("Sleeping Thread is sleeping for 3 seconds.");
                Thread.sleep(3000);
                System.out.println("Sleeping Thread woke up after 3 seconds.");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        // Thread 2: Wait and Notify example
        Thread waitNotifyThread = new Thread(() -> {
            synchronized (sharedResource) {
                try {
                    System.out.println("Wait-Notify Thread is waiting.");
                    sharedResource.wait();
                    System.out.println("Wait-Notify Thread is notified and resumed.");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        // Start both threads
        sleepThread.start();
        waitNotifyThread.start();

        // Main thread sleeps for 2 seconds and then notifies the waiting thread
        try {
            Thread.sleep(2000);
            synchronized (sharedResource) {
                System.out.println("Main Thread notifying the Wait-Notify Thread.");
                sharedResource.notify();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class SharedResource {
    // This class is used for synchronization with wait() and notify()
}
