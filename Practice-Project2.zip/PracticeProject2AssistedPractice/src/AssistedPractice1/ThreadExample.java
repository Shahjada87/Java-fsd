package AssistedPractice1;

class MyThread extends Thread implements Runnable {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Thread " + Thread.currentThread().getId() + " - Count: " + i);
        }
    }
}

public class ThreadExample {
    public static void main(String args[]) {
        // Creating and starting thread using Thread class
        MyThread thread1 = new MyThread();
        thread1.start();

        // Creating and starting thread using Runnable interface
        Thread thread2 = new Thread(new MyThread());
        thread2.start();
    }
}