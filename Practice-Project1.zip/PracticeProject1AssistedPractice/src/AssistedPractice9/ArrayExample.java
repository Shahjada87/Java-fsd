package AssistedPractice9;

public class ArrayExample {
    public static void main(String[] args) {
        // Declare and initialize an array of integers
        int[] intArray = {1, 2, 3, 4, 5};

        // Display the elements of the array
        System.out.println("Elements of the integer array:");
        for (int i = 0; i < intArray.length; i++) {
            System.out.print(intArray[i] + " ");
        }

        // Declare and initialize an array of strings
        String[] stringArray = {"Java", "Programming", "Example"};

        // Display the elements of the array
        System.out.println("\n\nElements of the string array:");
        for (int i = 0; i < stringArray.length; i++) {
            System.out.print(stringArray[i] + " ");
        }

        // Declare and initialize a two-dimensional array
        int[][] twoDArray = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

        // Display the elements of the two-dimensional array
        System.out.println("\n\nElements of the two-dimensional array:");
        for (int i = 0; i < twoDArray.length; i++) {
            for (int j = 0; j < twoDArray[i].length; j++) {
                System.out.print(twoDArray[i][j] + " ");
            }
            System.out.println();
        }
    }
}