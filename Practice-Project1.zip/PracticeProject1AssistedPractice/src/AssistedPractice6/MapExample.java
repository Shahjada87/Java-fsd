package AssistedPractice6;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapExample {
    public static void main(String[] args) {
        // Creating a HashMap
        Map<String, Integer> studentMarks = new HashMap<>();

        // Adding key-value pairs to the map
        studentMarks.put("John", 85);
        studentMarks.put("Alice", 92);
        studentMarks.put("Bob", 78);
        studentMarks.put("Eva", 95);

        // Displaying elements in the map
        System.out.println("Student Marks:");
        Set<Map.Entry<String, Integer>> entrySet = studentMarks.entrySet();
        for (Map.Entry<String, Integer> entry : entrySet) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Checking if a key exists and retrieving its value
        String studentName = "Alice";
        if (studentMarks.containsKey(studentName)) {
            int marks = studentMarks.get(studentName);
            System.out.println(studentName + "'s marks: " + marks);
        } else {
            System.out.println(studentName + " not found in the map.");
        }
    }
}