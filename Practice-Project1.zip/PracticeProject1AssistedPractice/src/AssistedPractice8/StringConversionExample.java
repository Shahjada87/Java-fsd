package AssistedPractice8;

public class StringConversionExample {
    public static void main(String[] args) {
        // Create a string
        String originalString = "Hello, World!";

        // Display the original string
        System.out.println("Original String: " + originalString);

        // Convert string to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(originalString);
        System.out.println("String converted to StringBuffer: " + stringBuffer);

        // Convert string to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(originalString);
        System.out.println("String converted to StringBuilder: " + stringBuilder);
    }
}