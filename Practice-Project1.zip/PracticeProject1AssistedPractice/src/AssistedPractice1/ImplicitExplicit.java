package AssistedPractice1;

public class ImplicitExplicit {
	    public static void main(String[] args) {
	        // Implicit Type Casting (Widening)
	        int intValue = 10;
	        long longValue = intValue; // Implicit casting from int to long
	        float floatValue = longValue; // Implicit casting from long to float
	        double doubleValue = floatValue; // Implicit casting from float to double

	        System.out.println("Implicit Type Casting:");
	        System.out.println("int: " + intValue);
	        System.out.println("long: " + longValue);
	        System.out.println("float: " + floatValue);
	        System.out.println("double: " + doubleValue);

	        // Explicit Type Casting (Narrowing)
	        double anotherDoubleValue = 123.456;
	        float anotherFloatValue = (float) anotherDoubleValue; // Explicit casting from double to float
	        long anotherLongValue = (long) anotherFloatValue; // Explicit casting from float to long
	        int anotherIntValue = (int) anotherLongValue; // Explicit casting from long to int

	        System.out.println("\nExplicit Type Casting:");
	        System.out.println("double: " + anotherDoubleValue);
	        System.out.println("float: " + anotherFloatValue);
	        System.out.println("long: " + anotherLongValue);
	        System.out.println("int: " + anotherIntValue);
	    }
}
