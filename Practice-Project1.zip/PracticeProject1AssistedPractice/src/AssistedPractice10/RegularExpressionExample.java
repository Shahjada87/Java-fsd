package AssistedPractice10;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressionExample {
    public static void main(String[] args) {
        // Define a regular expression pattern
        String regex = "Java";

        // Create a Pattern object
        Pattern pattern = Pattern.compile(regex);

        // Create a Matcher object
        Matcher matcher = pattern.matcher("Java Programming is fun with Java");

        // Find the first occurrence of the pattern
        if (matcher.find()) {
            System.out.println("Pattern found in the input string.");
        } else {
            System.out.println("Pattern not found in the input string.");
        }

        // Replace all occurrences of the pattern
        String replacedString = matcher.replaceAll("JavaSE");
        System.out.println("Modified String: " + replacedString);

        // Using matches() method for exact match
        String input = "Java";
        if (input.matches(regex)) {
            System.out.println("Exact match found.");
        } else {
            System.out.println("No exact match found.");
        }
    }
}