package AssistedPractice7;

class OuterClass {
    private int outerData = 10;

    // Inner class
    class InnerClass {
        void display() {
            System.out.println("Data from Outer class: " + outerData);
        }
    }

    // Method to use the inner class
    void useInnerClass() {
        InnerClass inner = new InnerClass();
        inner.display();
    }
}

public class InnerClassExample {
    public static void main(String[] args) {
        // Creating an instance of the outer class
        OuterClass outer = new OuterClass();

        // Using the inner class
        outer.useInnerClass();
    }
}