package AssistedPractice4;

public class ConstructorExample {
	
    public ConstructorExample() {
        System.out.println("Default Constructor");
    }

    // Constructor with parameters
    public ConstructorExample(String message) {
        System.out.println("Parameterized Constructor: " + message);
    }

    // Constructor overloading
    public ConstructorExample(int number) {
        System.out.println("Overloaded Constructor: " + number);
    }

    // Constructor chaining
    public ConstructorExample(String message, int number) {
        this(message); // Calls the parameterized constructor
        System.out.println("Chained Constructor: " + number);
    }

    public static void main(String[] args) {
        // Creating objects using different constructors

        // 1. Default Constructor
        ConstructorExample defaultConstructor = new ConstructorExample();

        // 2. Parameterized Constructor
        ConstructorExample paramConstructor = new ConstructorExample("Hello from Parameterized Constructor!");

        // 3. Overloaded Constructor
        ConstructorExample overloadedConstructor = new ConstructorExample(42);

        // 4. Constructor Chaining
        ConstructorExample chainedConstructor = new ConstructorExample("Chaining", 99);
    }
}
