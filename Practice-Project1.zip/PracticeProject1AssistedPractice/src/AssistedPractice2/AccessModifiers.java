package AssistedPractice2;

public class AccessModifiers {
	    // Public variable accessible from anywhere
	    public int publicVar = 10;

	    // Protected variable accessible within the same package and subclasses
	    protected int protectedVar = 20;

	    // Default (package-private) variable accessible only within the same package
	    int defaultVar = 30;

	    // Private variable accessible only within the same class
	    private int privateVar = 40;

	    // Public method accessible from anywhere
	    public void publicMethod() {
	        System.out.println("Public Method");
	    }

	    // Protected method accessible within the same package and subclasses
	    protected void protectedMethod() {
	        System.out.println("Protected Method");
	    }

	    // Default (package-private) method accessible only within the same package
	    void defaultMethod() {
	        System.out.println("Default Method");
	    }

	    // Private method accessible only within the same class
	    private void privateMethod() {
	        System.out.println("Private Method");
	    }

	    public static void main(String[] args) {
	        // Create an instance of the class
	    	AccessModifiers example = new AccessModifiers();

	        // Accessing variables and methods
	        System.out.println("Public Variable: " + example.publicVar);
	        System.out.println("Protected Variable: " + example.protectedVar);
	        System.out.println("Default Variable: " + example.defaultVar);
	        System.out.println("Private Variable: " + example.privateVar);

	        example.publicMethod();
	        example.protectedMethod();
	        example.defaultMethod();
	        example.privateMethod();
	    }
}
