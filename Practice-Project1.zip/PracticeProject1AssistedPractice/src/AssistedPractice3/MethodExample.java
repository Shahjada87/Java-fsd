package AssistedPractice3;

public class MethodExample {
	public static void greet() {
        System.out.println("Hello! Welcome to Java Methods.");
    }

    // Method with parameters and a return value
    public static int add(int a, int b) {
        return a + b;
    }

    // Method with a different signature (method overloading)
    public static double add(double a, double b) {
        return a + b;
    }

    // Method with variable number of arguments
    public static int sum(int... numbers) {
        int result = 0;
        for (int num : numbers) {
            result += num;
        }
        return result;
    }

    // Method with a return type of a custom class
    public static Person createPerson(String name, int age) {
        return new Person(name, age);
    }

    // Entry point of the program
    public static void main(String[] args) {
        // Calling methods in different ways

        // 1. Calling a method with no parameters and no return value
        greet();

        // 2. Calling a method with parameters and a return value
        int sumResult = add(5, 10);
        System.out.println("Sum Result: " + sumResult);

        // 3. Method overloading - calling the version with double parameters
        double doubleSumResult = add(3.5, 2.5);
        System.out.println("Double Sum Result: " + doubleSumResult);

        // 4. Method with variable number of arguments
        int variableSumResult = sum(1, 2, 3, 4, 5);
        System.out.println("Variable Sum Result: " + variableSumResult);

        // 5. Method with a return type of a custom class
        Person person = createPerson("John", 25);
        System.out.println("Created Person: " + person.getName() + ", Age: " + person.getAge());
    }
}

// Custom class used in the program
class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
