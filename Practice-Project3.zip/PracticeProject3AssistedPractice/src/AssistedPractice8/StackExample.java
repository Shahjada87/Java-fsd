package AssistedPractice8;

import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
        // Create a stack
        Stack<Integer> stack = new Stack<>();

        // Insert elements into the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);

        // Display the stack elements
        System.out.println("Stack elements: " + stack);

        // Remove the top element from the stack
        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);

        // Display the stack elements after removal
        System.out.println("Stack elements after pop: " + stack);

        // Insert a new element into the stack
        stack.push(50);
        System.out.println("Stack elements after push: " + stack);
    }
}