package AssistedPractice2;

import java.util.Arrays;

public class FourthSmallestElement {

    public static void main(String[] args) {
        // Sample unsorted list
        int[] unsortedList = {12, 5, 8, 3, 15, 7, 10, 9};

        // Find the fourth smallest element
        int fourthSmallest = findFourthSmallestElement(unsortedList);

        // Display the result
        System.out.println("Fourth Smallest Element: " + fourthSmallest);
    }

    // Method to find the fourth smallest element in an unsorted list
    private static int findFourthSmallestElement(int[] arr) {
        // Sort the array in ascending order
        Arrays.sort(arr);

        // Check if the array has at least four elements
        if (arr.length >= 4) {
            return arr[3]; // Fourth smallest element
        } else {
            System.out.println("List does not have at least four elements.");
            return -1;
        }
    }
}