package AssistedPractice1;

public class RightRotateArray {

    public static void main(String[] args) {
        // Sample array
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        // Number of steps to rotate
        int steps = 5;

        // Display the original array
        System.out.println("Original Array:");
        displayArray(array);

        // Right rotate the array by 5 steps
        rightRotateArray(array, steps);

        // Display the rotated array
        System.out.println("\nArray after Right Rotation by " + steps + " steps:");
        displayArray(array);
    }

    // Method to right rotate an array by specified steps
    private static void rightRotateArray(int[] arr, int steps) {
        int length = arr.length;
        steps = steps % length; // Handle cases where steps are greater than array length

        int[] temp = new int[length];

        // Copy the last 'steps' elements to temp
        System.arraycopy(arr, length - steps, temp, 0, steps);

        // Shift the remaining elements to the right
        System.arraycopy(arr, 0, arr, steps, length - steps);

        // Copy the elements from temp back to the array
        System.arraycopy(temp, 0, arr, 0, steps);
    }

    // Method to display an array
    private static void displayArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}