package AssistedPractice9;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        // Create a queue
        Queue<Integer> queue = new LinkedList<>();

        // Insert elements into the queue
        queue.add(10);
        queue.add(20);
        queue.add(30);
        queue.add(40);

        // Display the queue elements
        System.out.println("Queue elements: " + queue);

        // Remove the front element from the queue
        int removedElement = queue.poll();
        System.out.println("Removed element: " + removedElement);

        // Display the queue elements after removal
        System.out.println("Queue elements after poll: " + queue);

        // Insert a new element into the queue
        queue.add(50);
        System.out.println("Queue elements after offer: " + queue);
    }
}