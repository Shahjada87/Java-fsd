package AssistedPractice7;

class Node {
    int data;
    Node prev;
    Node next;

    Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    Node head;

    DoublyLinkedList() {
        this.head = null;
    }

    // Method to insert a new node at the end of the doubly linked list
    void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.prev = temp;
        }
    }

    // Method to traverse the doubly linked list in the forward direction
    void traverseForward() {
        System.out.println("Doubly Linked List (Forward):");
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    // Method to traverse the doubly linked list in the backward direction
    void traverseBackward() {
        System.out.println("Doubly Linked List (Backward):");
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.prev;
        }
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        DoublyLinkedList doublyList = new DoublyLinkedList();
        doublyList.insert(3);
        doublyList.insert(7);
        doublyList.insert(10);
        doublyList.insert(15);

        doublyList.traverseForward();
        doublyList.traverseBackward();
    }
}
