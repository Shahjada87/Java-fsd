package AssistedPractice6;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    Node head;

    SortedCircularLinkedList() {
        this.head = null;
    }

    // Method to insert a new node into a sorted circular linked list
    void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            head.next = head;
        } else if (data <= head.data) {
            // Insert at the beginning
            newNode.next = head;
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            head = newNode;
        } else {
            // Insert in the middle or at the end
            Node temp = head;
            while (temp.next != head && temp.next.data < data) {
                temp = temp.next;
            }
            newNode.next = temp.next;
            temp.next = newNode;
        }
    }

    // Method to display the sorted circular linked list
    void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node temp = head;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != head);

        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        SortedCircularLinkedList circularList = new SortedCircularLinkedList();
        circularList.insert(3);
        circularList.insert(7);
        circularList.insert(10);
        circularList.insert(15);

        System.out.println("Original Sorted Circular Linked List:");
        circularList.display();

        // Insert a new element (e.g., 8)
        int newElement = 8;
        circularList.insert(newElement);

        System.out.println("Sorted Circular Linked List after inserting " + newElement + ":");
        circularList.display();
    }
}