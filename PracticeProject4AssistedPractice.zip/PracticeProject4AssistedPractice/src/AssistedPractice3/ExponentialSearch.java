package AssistedPractice3;

import java.util.Arrays;
import java.util.Scanner;

public class ExponentialSearch {

    // Function to perform exponential search
    public static int exponentialSearch(int[] array, int target) {
        int size = array.length;

        // If the target is the first element
        if (array[0] == target) {
            return 0;
        }

        // Find the range for binary search by doubling i
        int i = 1;
        while (i < size && array[i] <= target) {
            i *= 2;
        }

        // Perform binary search within the identified range
        return Arrays.binarySearch(array, i / 2, Math.min(i, size), target);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input array size
        System.out.print("Enter the size of the sorted array: ");
        int size = scanner.nextInt();

        // Input sorted array elements
        int[] array = new int[size];
        System.out.println("Enter the sorted array elements:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }

        // Input target element to search
        System.out.print("Enter the element to search: ");
        int target = scanner.nextInt();

        // Perform exponential search
        int result = exponentialSearch(array, target);

        // Display the result
        if (result >= 0) {
            System.out.println("Element " + target + " found at index " + result);
        } else {
            System.out.println("Element " + target + " not found in the array");
        }

        scanner.close();
    }
}