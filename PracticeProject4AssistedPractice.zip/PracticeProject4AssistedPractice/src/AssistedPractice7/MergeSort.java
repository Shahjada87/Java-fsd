package AssistedPractice7;

import java.util.Arrays;

public class MergeSort {

    // Function to merge two subarrays of array[].
    // First subarray is array[l..m]
    // Second subarray is array[m+1..r]
    public static void merge(int[] array, int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        // Create temporary arrays
        int[] leftArray = Arrays.copyOfRange(array, l, l + n1);
        int[] rightArray = Arrays.copyOfRange(array, m + 1, m + 1 + n2);

        // Merge the temporary arrays back into array[l..r]
        int i = 0, j = 0, k = l;
        while (i < n1 && j < n2) {
            if (leftArray[i] <= rightArray[j]) {
                array[k++] = leftArray[i++];
            } else {
                array[k++] = rightArray[j++];
            }
        }

        // Copy remaining elements of leftArray[] if any
        while (i < n1) {
            array[k++] = leftArray[i++];
        }

        // Copy remaining elements of rightArray[] if any
        while (j < n2) {
            array[k++] = rightArray[j++];
        }
    }

    // Main function that sorts array[l..r] using merge()
    public static void mergeSort(int[] array, int l, int r) {
        if (l < r) {
            // Find the middle point
            int m = (l + r) / 2;

            // Sort first and second halves
            mergeSort(array, l, m);
            mergeSort(array, m + 1, r);

            // Merge the sorted halves
            merge(array, l, m, r);
        }
    }

    public static void main(String[] args) {
        int[] array = {12, 11, 13, 5, 6, 7};

        System.out.println("Original array: " + Arrays.toString(array));

        // Perform merge sort
        mergeSort(array, 0, array.length - 1);

        System.out.println("Array after merge sort: " + Arrays.toString(array));
    }
}