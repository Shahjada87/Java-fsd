package AssistedPractice6;

import java.util.Arrays;

public class InsertionSort {

    // Function to perform insertion sort on an array
    public static void insertionSort(int[] array) {
        int size = array.length;

        for (int i = 1; i < size; ++i) {
            int key = array[i];
            int j = i - 1;

            // Move elements of the array that are greater than key to one position ahead of their current position
            while (j >= 0 && array[j] > key) {
                array[j + 1] = array[j];
                j = j - 1;
            }
            array[j + 1] = key;
        }
    }

    public static void main(String[] args) {
        int[] array = {64, 34, 25, 12, 22, 11, 90};

        System.out.println("Original array: " + Arrays.toString(array));

        // Perform insertion sort
        insertionSort(array);

        System.out.println("Array after insertion sort: " + Arrays.toString(array));
    }
}